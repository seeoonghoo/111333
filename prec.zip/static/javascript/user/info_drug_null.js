$( document ).ready( function() {
    $('.input_pretty').click(function(){
    
        location.href='/camera';
    })

})