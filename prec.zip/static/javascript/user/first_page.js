$( document ).ready( function() {
    $('#camera').click(function(){
        location.href='/camera';
    })
    $('#login').click(function(){
        location.href='/login_form';
    })
    $('#sign').click(function(){
        location.href='/sign_agree';
    })

})