$( document ).ready( function() {

    $(".navi").hide();

    $('.text_chech').click(function(){
        location.href = '/personal_infomation_processing_policy';
    });

});